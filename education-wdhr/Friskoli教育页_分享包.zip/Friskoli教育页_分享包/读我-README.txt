Friskoli 教育页 · 分享包
=========================

一、只想看内容（推荐）
  直接打开 教育-Friskoli课堂科普.html 或 Education-Friskoli-Classroom-Outreach.html。
  图片已经编在网页文件里，不需要任何其他文件，双击即可，发给别人也不会掉图。
  想转 PDF：用浏览器打开后 Ctrl+P，目标选"另存为 PDF"。打印样式已做过适配，目录会自动隐藏。

二、要改文字（需要 .md）
  包里的两个 .md 文件必须和这 12 张图片放在同一个文件夹里，图片才能显示。
  原因：markdown 里的图是引用（photo_artemia_cysts.jpg 这样的文件名），不是图片本身。
  单独把 .md 发出去，对方没有这些文件，就只能看到空白。
  因此要发 md 给别人编辑时，请把整个文件夹压缩后一起发，不要只发 .md。

  两个 md 的分工：
  Education-Friskoli-Classroom-Outreach-en.md   英文稿，贴 wiki 用这版
  Education-Friskoli-Classroom-Outreach-zh.md   中文稿，内部沟通与存档

三、要贴到 iGEM Wiki
  先按 wiki 的图片上传流程把 12 张图传上去，再把 .md 里的文件名替换成上传后的地址。
  文字部分可以直接复制。

图片清单（共 12 张）
  photo_lufeng_classroom_1.jpg     支教课堂
  photo_classroom_overview.jpg     深圳初中·黄裕谦教授知识引入
  photo_story_presentation.jpg     深圳初中·学生讲剧情
  photo_artemia_cysts.jpg          丰年虾卵（试剂罐）
  photo_artemia_nauplius.png       丰年虾无节幼体（图源：百度百科）
  photo_recording_sheet.jpg        学生手绘记录单
  photo_laptop_game.jpg            玩趋化棋
  survey_figure.png                问卷结果图
  photo_survey_writing.jpg         学生填写记录单
  questionnaire_zh.png             中文问卷
  questionnaire_en.png             英文问卷
  education_dbtl.png               DBTL 循环图
