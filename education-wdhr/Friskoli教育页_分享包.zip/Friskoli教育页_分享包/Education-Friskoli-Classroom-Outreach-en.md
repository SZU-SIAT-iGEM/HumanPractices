# Education

## Overview

> "Seeing a thing a thousand times is not as good as doing it once with your own hands."  
> — Chinese proverb

When we began planning our education work, we asked ourselves a question that had nothing to do with enzymes or plasmids: what does a thirteen-year-old actually need in order to understand chemotaxis?

Our project is about helping a cell find food it cannot see. It cannot be told where the food is. It has to swim toward it. Teaching, we found, works the same way. No student can be handed a conclusion and be expected to keep it; they have to move toward the answer themselves, one small step at a time, and the gradient has to be set up by whoever is teaching.

The saying is old and has no author, and we only learned how literally it held once our own questionnaire came back: 77.4% of the students named the block where they handled the animals as the part that helped them most, against 25.8% for our explanation. They had told us, in numbers, that a hand does more than an eye.

So we set up three gradients for three very different groups of students. For primary school children in a rural coastal town, we told the story and let them touch the science. For junior high students in Shenzhen, we let them run an experiment, argue about what they saw, and then answer the same questions twice so we could find out what actually stuck. And for third-year marine science majors at Shenzhen University, we brought the same project into their own discipline and let them interrogate it.

---

## For Younger Learners: Telling the Story

### Lufeng Neihu Town Central Primary School

On 12 August 2026, we went to Lufeng Neihu Town Central Primary School to meet a class of primary school students from Grades 3 and 4 with almost no exposure to biology. What they had was curiosity and a great deal of energy, so we built them a story rather than a lecture.

The story is set in 2049. Astronaut Lili has landed in a lunar capsule for a thirty-day mission, carrying food for only seven days. Her assistant is not a robot but an engineered cleaning *E. coli*, sent along to solve the problem she cannot solve alone: what to do with thirty days of waste when nothing can be resupplied.

The children followed Lili through three problems. First, the waste itself — we showed them how solid waste on the International Space Station is sealed into bags and burned up in the atmosphere, and asked whether that was a loss or a solution. Second, the physical trap: in microgravity nothing stirs the liquid, so food never reaches the bacteria. We proposed mechanical stirring, and then took it apart with the class — the blades would damage the cells, the bubbles would block the food, the heat would build up with nowhere to go. Third, the way out. Re-activating a silent operon so the bacterium can taste cellobiose, swim toward it, and call others to the same spot.

By the end, the children could say the name of the system with us: *Friskoli*, from *frisk*, for the swimming, and *coli*, for the bacterium that does the swimming.

![Students following the story](photo_lufeng_classroom_1.jpg)

**Students following the story**

After the lesson we gave them a link to our mini-game *Lunar Mission: Thirty Days Survival*, so that the mission would not end when the class did. The game lets them replay Lili's thirty days at home and see whether their own decisions keep her alive.

---

## For Older Learners: Running the Experiment

### Shenzhen Experimental School (Junior High Section)

On the afternoon of 14 October 2026, Shangru Wu, Denghuirong Wang and Mofei He went to Shenzhen Experimental School (Junior High Section) with our supervising teacher Yuqian Huang, to meet 42 students from Grades 7 and 8.

![The session](photo_classroom_overview.jpg)

**Professor Yuqian Huang leading the knowledge-introduction segment**

![Storytelling](photo_story_presentation.jpg)

**A student volunteer presenting the mission story**

We had planned something more ambitious than a lecture. We wanted the students to see chemotaxis with their own eyes, in a living organism, within a single class period.

We originally planned to run a real bacterial chemotaxis assay with the students. But we abandoned that plan for three reasons.

1. Biosafety. The audience was minors in a school laboratory without BSL-1 supervision. Bringing live engineered *E. coli* into that room was not acceptable, and we did not want to teach synthetic biology by first teaching students that safety rules can be bent.
2. Time. A bacterial chemotaxis assay needs overnight culture and a readout minutes to hours later. A single class period cannot contain that.
3. Materials. Capillary tubes, a microscope with a tracking setup, and an incubator were not available in the numbers a class of 42 would need.

Instead of cancelling the experiment, we replaced the organism while keeping the concept intact. Brine shrimp nauplii (*Artemia*) show strong positive phototaxis: in a shallow dish with one half illuminated, they migrate toward the light within minutes. The behavioural logic is the same as chemotaxis — biased movement along a gradient toward a favourable cue — only the cue (light instead of cellobiose) and the organism change.

![Artemia cysts](photo_artemia_cysts.jpg)

**The brine shrimp eggs we used**

![Brine shrimp nauplius](photo_artemia_nauplius.png)

**A brine shrimp nauplius (image source: [Baidu Baike](https://baike.baidu.com/item/%E4%B8%B0%E5%B9%B4%E8%99%BE/1252809))**

In the record sheet below, one student drew the dish as a nine-zone grid, marked every shrimp as a small dot, sketched the lamp shining in from the lower left, and labelled the page "experimental group". That drawing is, in a small way, the whole idea of a controlled experiment.

![Recording sheet](photo_recording_sheet.jpg)

**A student's drawing of the experimental group: each dot is a brine shrimp, and the lamp sketched at the lower left is the light source. The animals cluster in the zones nearest the lamp.**

Afterwards we played our chemotaxis board game, in which each player is an *E. coli* navigating a sugar gradient with run and tumble cards. Students actively played a round, and one of them wrote on the feedback sheet that the game was "really interesting".

![Playing the game](photo_laptop_game.jpg)

**Playing the mini-game with a team member**

### What the Questionnaire Told Us

We did not want to end the session with our own impression of how it had gone, so we designed a two-sided sheet called *Friskoli Science Field Notes*. The front side was filled in before the lesson and the back side after it; students wrote the same anonymous code on both sides, so the two halves could be matched without collecting a single name. Participation was voluntary and ungraded: any question could be skipped, and nobody was excluded from any activity for leaving it blank. Thirty-two of the forty-two students returned the sheet.

The first thing it told us was that the students began from a low baseline. Before the lesson, 64.5% of respondents had never encountered bacterial chemotaxis, and only one student could roughly explain it. Space resource recycling was only slightly more familiar.

The second thing it told us was that the brine shrimp worked. When we asked which part of the session had helped them most, 77.4% chose watching the shrimp, against 25.8% for the science explanation. By a factor of three, the students preferred the part where they did something to the part where we talked.

Enjoyment averaged 4.35 out of 5, with not a single rating below 3, and the share of students who wanted to learn more about microbes or synthetic biology rose from 66.7% to 77.4%. On the one reasoning item we repeated word for word before and after — how to compare shrimp distributions under different lighting — correct answers moved from 74.1% to 77.8%, and the number answering "I am not sure yet" halved.

![Survey results](survey_figure.png)

**What the paired survey showed: prior exposure, the repeated item, and the most helpful block**

The third thing it told us was the most useful, and it was not good news. On the question about *how* a bacterium finds food, correct answers fell from 36.7% before the lesson to 16.7% after it, and 56.7% of students chose the option that describes an animal: compare the concentration at both ends of the body, then turn toward the higher side. That is exactly how a brine shrimp finds a lamp. It is not how *E. coli* works.

We had taught the behaviour so vividly that the students gave the bacterium the shrimp's method.

Seven of the eleven students who had answered correctly before the lesson chose the same letter afterwards, even though that letter now meant something different. Our own analogy had anchored them, and the questionnaire let us see it.

This is the finding we are most grateful for, because it is the one we could not have guessed from the smiles in the classroom. An analogy has to be dismantled as deliberately as it is introduced. In our next round we will put a single slide between the shrimp and the bacterium: the shrimp has organs and turns directly; the bacterium has no organs at all, remembers for a few seconds, and changes how often it tumbles. We will also cut the post-test from five items to three, because we watched skipping rise from about 7% to about 20% on the longest items, and a question nobody finishes tells us nothing.

![Filling in the field notes](photo_survey_writing.jpg)

**Students are conducting the phototaxis experiment with *brine shrimp nauplii***

![Questionnaire, Chinese](questionnaire_zh.png)

**The Chinese version used in class: before (left) and after (right)**

![Questionnaire, English](questionnaire_en.png)

**The English version of the same sheet**

---

## On Campus: Friskoli for Marine Science Majors


Education does not stop at the school gate. Team member Le Chen took Friskoli into a science class at Shenzhen University, for third-year marine science majors — students who already know their microbiology and oceanography, and who ask sharper questions than a school classroom ever will.

For this audience the storyline stayed the same, but the depth moved from "what is chemotaxis" to where our design actually meets their discipline: mass transfer at surfaces, mixing without gravity, and what a microbial bioreactor has to prove before it can leave the bench. `[TBD: date, class size, and the specific topics Le Chen covered — ask the team before publishing]`

---

## The Education DBTL

We ran our education work the way we run our bench work: as a Design–Build–Test–Learn cycle.

![Education DBTL](education_dbtl.png)

**Design.** Three things were fixed before anyone visited a classroom: one storyline (Lili's 2049 mission) that could be told at three depths for three audiences; a replacement organism for the experiment we could not safely run, chosen so that phototaxis would carry the logic of chemotaxis into a dish; and a two-sided paired questionnaire with anonymous codes, so that we could measure change instead of collecting praise.

**Build.** The story class and mini-game went to Lufeng Neihu Town Central Primary School. The brine shrimp assay, the chemotaxis board game and the paired survey went to Shenzhen Experimental School (Junior High Section). And Le Chen carried Friskoli across the city to a class of third-year marine science majors at Shenzhen University.

**Test.** The questionnaire did its job: 32 of 42 sheets came back paired. Enjoyment averaged 4.35 out of 5 with no rating below 3, interest in learning more about synthetic biology rose from 66.7% to 77.4%, and the hands-on block was named most helpful by 77.4% of students — three times the share for our lecture. But the test also caught what the smiles in the classroom hid: on the mechanism item, correct answers fell from 36.7% to 16.7%, and 56.7% of students gave the bacterium the shrimp's way of finding food.

**Learn.** Three changes are already designed into the next round: a slide that dismantles the shrimp analogy explicitly (organs turn directly; bacteria remember and change how often they tumble); a shorter post-test with diagram-based items, because skipping rose to about 20% on the longest questions; and consistent option positions for matched items. The analogy check also goes into the primary-school deck — if junior high students imported the shrimp's mechanism, younger children will import it faster.

---

## What We Carry Forward

The three programmes look very different on paper — a storybook for children, a paired survey for teenagers, a campus class for future oceanographers — but they came from the same decision. In Lufeng the constraint was age, and abstraction had to become narrative. In Shenzhen the constraints were biosafety, time and materials, and a bacterial assay had to become a brine-shrimp assay. At Shenzhen University the constraint was the audience's own expertise, and the storyline had to give way to the discipline. In every case we kept the principle and changed the parts, and in every case we said so out loud, because that is what engineering is.

And in all three cases the students taught us something we had not planned to learn: that a good analogy can carry a behaviour into a mind while smuggling in the wrong mechanism behind it.

## Materials for Reuse

Our questionnaire (Chinese and English), the brine shrimp protocol, the board game print files, the mini-game link and the slide decks are available for other teams to reuse: `[TBD: add links]`. We only ask that the safety note travels with the protocol — the substitution works because brine shrimp are harmless and fast, and that is precisely why it can be done in a school at all.
